import React, { Component } from 'react';

class CardAcompUF extends Component {
    constructor(props) {
      super(props);
      this.state = {
        eleicao: props.eleicao
      };
    }
    
render(){
    return (
        <div></div>
    );
}
}