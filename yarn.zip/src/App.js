import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Painel from './components/PainelVotacao';
import Abrangencia from './components/Abrangencia';
import abrangencias from './abrangencias.json';
import Indice from './components/Indice';
import Validacao from './components/Validacao';

class App extends Component {
  constructor() {
    super();
    this.state = {
      chartSecoes: {},
      isLoading: false,
      isLoadingCargo: {
        '1': false,
        '3': false,
        '5': false,
        '6': false,
        '7': false,
        '8': false
      },
      error: null,
      abrangenciaSelecionada: 'aa',
      abrangenciasDisponiveis: [],
      configuracaoEleicao: {},
      eleicoesDisponiveis: [],
      eleicoesCarregadas: [],
      eleicoes: {
        '1': [],
        '3': [],
        '5': [],
        '6': [],
        '7': [],
        '8': []
      },
      evolucao: [],
      url: 'https://resultados-hmg.tse.jus.br/',
      ambiente: 'homologacao',
      showFlags: true,
      mostrarFotos: true,
      mostrarEleicoesRecentes: false,
      chkValidacoes: true,
      chkDivulgaShell: false,
      municipiosConfigurados: [],
      arquivoDeIndice: [],
      erroValidacaoJSON: [],
      erroValidacaoXML: [],
      dadosDivShellNew: [],
      dadosDivShellOld: [],
      errosDivulgacaoNew: [],
      errosDivulgacaoOld: [],
      photoUrl: {},
      eleicoesConfiguradas: {}
    };
    this.handleAbrangenciaChange = this.handleAbrangenciaChange.bind(this);
    this.handleAmbienteChange = this.handleAmbienteChange.bind(this);
    this.handleShowFlagsChange = this.handleShowFlagsChange.bind(this);
    this.handleMostrarFotosChange = this.handleMostrarFotosChange.bind(this);
    this.handleMostrarEleicoesRecentesChange = this.handleMostrarEleicoesRecentesChange.bind(
      this
    );
    this.handleChkDivulgaShellChange = this.handleChkDivulgaShellChange.bind(
      this
    );
    this.handleChkValidacoesChange = this.handleChkValidacoesChange.bind(this);
    this.handleEleicaoChange = this.handleEleicaoChange.bind(this);
    this.handleMunicipioChange = this.handleMunicipioChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleClickCargo = this.handleClickCargo.bind(this);
    this.handleRegerarIndice = this.handleRegerarIndice.bind(this);
    this.handleClickErrosDivulgacao = this.handleClickErrosDivulgacao.bind(
      this
    );
  }
  handleClick = () => this.atualizar();

  handleClickCargo(e) {
    if (
      this.state.eleicaoSelecionada === '' ||
      this.state.abrangenciaSelecionada === 'aa'
    ) {
      return;
    }
    console.log(e.currentTarget.id);
    
    var idcargo = e.currentTarget.id;
    //this.state.isLoadingCargo[idcargo] = true;
    var isLoadingCargo = this.state.isLoadingCargo;
    isLoadingCargo[idcargo] = true;
    this.setState({isLoadingCargo:isLoadingCargo});
   // this.carregaArquivosResultadoPorCargo(idcargo);
    
  }

  atualizar() {
    this.setState({
      eleicoes: {
        '1': [],
        '3': [],
        '5': [],
        '6': [],
        '7': [],
        '8': []
      },
      evolucao: [],
      erroValidacaoJSON: [],
      erroValidacaoXML: [],
      arquivoDeIndice: []
    });
    if (
      this.state.eleicaoSelecionada === '' ||
      this.state.abrangenciaSelecionada === 'aa'
    ) {
      return;
    }
    if (
      this.state.eleicaoSelecionada.tp === '3' ||
      this.state.eleicaoSelecionada.tp === '4' ||
      this.state.eleicaoSelecionada.tp === '7'
    ) {
      this.carregaArquivoResultadoMunicipio(
        document.getElementById('comboMunicipio').value
      );
    } else {
      this.carregaArquivosResultadoPorEleicao(
        this.state.abrangenciaSelecionada,
        this.state.eleicaoSelecionada
      );
      for (var i = 0; i < this.state.eleicaoSelecionada.cargos.length; i++) {
        if (
          this.state.eleicaoSelecionada.cargos[i].cd === '1' ||
          this.state.eleicaoSelecionada.cargos[i].cd === '3' ||
          this.state.eleicaoSelecionada.cargos[i].cd === '5' ||
          this.state.eleicaoSelecionada.cargos[i].cd === '11'
        ) {
          this.carregaEvolucao(
            this.state.abrangenciaSelecionada,
            this.state.eleicaoSelecionada,
            this.state.eleicaoSelecionada.cargos[i].cd
          );
        }
      }
      if (this.state.chkValidacoes) {
        this.carregaValidacaoArquivoIndice(
          this.state.abrangenciaSelecionada,
          this.state.eleicaoSelecionada
        );
        this.carregaValidacaoArquivosXML(
          this.state.abrangenciaSelecionada,
          this.state.eleicaoSelecionada
        );
      }
    }
  }

  handleEleicaoChange(e) {
    if (e.target.value !== '') {
      var pleito = e.target.value.split('-')[0];
      var cdeleicao = e.target.value.split('-')[1];
      var eleicao;
      var abrangenciaSelecionada = 'aa';

      eleicao = this.state.configuracaoEleicao.pl[pleito].e[cdeleicao];

          
      if (eleicao.abr.length === 1) {
        abrangenciaSelecionada = eleicao.abr[0].cd.toLowerCase();
        this.setState({abrangenciaSelecionada: abrangenciaSelecionada});
      }
      this.carregaArquivoConfiguracaoMunicipios(eleicao);

      this.setState({
        eleicaoSelecionada: eleicao,
        eleicoesCarregadas: [],
        municipioSelecionado: undefined,
        municipiosConfigurados: [],
        eleicoes: {
          '1': [],
          '3': [],
          '5': [],
          '6': [],
          '7': [],
          '8': [],
          '55': [],
          '57': [],
        },
        evolucao: [],
        erroValidacaoJSON: [],
        erroValidacaoXML: [],
        arquivoDeIndice: []
      });
      document.getElementById('comboMunicipio').value = '';
      document.getElementById('comboMunicipio').style.display = 'none';
    }
  }
  selecionaAbrangencia(abrangencia) {
    this.setState({
      abrangenciaSelecionada: abrangencia.toLowerCase(),
      eleicoesCarregadas: [],
      municipioSelecionado: undefined,
      municipiosConfigurados: []
    });
    var eleicoes = this.state.eleicoes;
    var eleicoesCarregadas = [];
    for (var j=0; j<this.state.eleicaoSelecionada.abr[0].cp.length;j++){
      var carper = this.state.eleicaoSelecionada.abr[0].cp[j].cd;
      for (var i=0; i<eleicoes[carper].length;i++){
        if (eleicoes[carper][i].cdabr.toLowerCase() === abrangencia){
          eleicoesCarregadas.push(eleicoes[carper][i]);
        }
      }
    }
    //console.log(eleicoesCarregadas);
    this.carregaArquivoAcompanhamentoUF(this.state.eleicaoSelecionada,abrangencia);
    this.setState({eleicoesCarregadas:eleicoesCarregadas});


    /*document.getElementById('comboMunicipio').value = '';
    document.getElementById('comboMunicipio').style.display = 'none';
    if (eleicao.tp === '3' || eleicao.tp === '4' || eleicao.tp === '7') {
      document.getElementById('comboMunicipio').style.display = 'block'; //className="collapse show";
      //this.carregaArquivoConfiguracaoMunicipios(eleicao);
    } else {
    //  this.carregaArquivosResultadoPorEleicao(abrangencia, eleicao);
      for (var i = 0; i < eleicao.abr[0].cp.length; i++) {
        if (
          eleicao.abr[0].cp[i].cd === '1' ||
          eleicao.abr[0].cp[i].cd === '3' ||
          eleicao.abr[0].cp[i].cd === '5' ||
          eleicao.abr[0].cp[i].cd === '11'
        ) {
          //for (var j = 0; j < this.state.eleicaoSelecionada.cdabr.length; j++) {
        //  this.carregaEvolucao(            abrangencia,            eleicao,            //this.state.eleicaoSelecionada.cdabr[j],            eleicao.cargos[i].cd);
          //}
        }
      }
    }
    if (this.state.chkValidacoes) {
   //   this.carregaValidacaoArquivoIndice(abrangencia, eleicao);
     // this.carregaValidacaoArquivosXML(abrangencia, eleicao);
    }*/
  }
  handleAbrangenciaChange(abrangencia) {
    this.selecionaAbrangencia(abrangencia);
  }
  handleMunicipioChange(e) {
    if (e.target.value !== '') {
      this.setState({
        municipioSelecionado: this.state.municipiosConfigurados[e.target.value]
      });
      this.carregaArquivoResultadoMunicipio(
        e.target.value
      );
    }
  }

  handleAmbienteChange(e) {
    this.setState({
      eleicoes: {
        '1': [],
        '3': [],
        '5': [],
        '6': [],
        '7': [],
        '8': []
      },
      eleicaoSelecionada: undefined,
      abrangenciaSelecionada: 'aa',
      evolucao: [],
      erroValidacaoJSON: [],
      erroValidacaoXML: [],
      arquivoDeIndice: [],
      ambiente: e.target.value,
      isLoading: true,
      eleicoesConfiguradas: {},
      eleicoesCarregadas: []
    });
    this.carregarArquivosConfiguracaoEleicao(e.target.value);
  }
  handleShowFlagsChange() {
    this.setState({ showFlags: !this.state.showFlags });
  }
  handleMostrarFotosChange() {
    this.setState({ mostrarFotos: !this.state.mostrarFotos });
  }
  handleMostrarEleicoesRecentesChange() {
    this.setState({
      mostrarEleicoesRecentes: !this.state.mostrarEleicoesRecentes
    });
  }
  handleChkValidacoesChange() {
    this.setState({ chkValidacoes: !this.state.chkValidacoes });
  }
  handleChkDivulgaShellChange() {
    this.setState({ chkDivulgaShell: !this.state.chkDivulgaShell });
  }
  handleSubmit(event) {
    event.preventDefault();
  }
  handleClickErrosDivulgacao() {
    this.loadErrosDivulgacao();
  }
  handleRegerarIndice(e) {
    console.log(e);
    var codigoSituacao;
    for (var i = 0; i < this.state.arquivoDeIndice.length; i++) {
      codigoSituacao = parseInt(
        this.state.arquivoDeIndice[i].codigoSituacao,
        10
      );
      if (codigoSituacao === parseInt(e, 10)) {
        console.log(
          this.state.arquivoDeIndice[i].caminhoArquivo.split(
            'divulga.tse.jus.br'
          )[1]
        );
        // this.reprocessarIndice(this.state.arquivoDeIndice[i].caminhoArquivo.split('divulga.tse.jus.br')[1]);
      }
    }
  }
  reprocessarIndice(caminhoArquivo) {
    var url =
      'https://appsdiv:9443/rec-arquivos-divulgacao-homologacaotre/rest/reprocessar/arquivos/indice';
    var caminho = '/aplic/sepel1/dados' + caminhoArquivo;
    console.log(url);
    fetch(url, {
      method: 'post',
      body: {
        caminho: caminho
      }
    })
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        console.log(data);
        this.setState({
          isLoading: false
        });
      })
      .catch(error => {
        this.setState({ error, isLoading: false });
      });
  }

  loadDivulgaShell() {
    var url = 'http://setot.tse.jus.br:9000/resultado-divulga-shell/';
    console.log(url);
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        this.setState({
          dadosDivShellOld: this.state.dadosDivShellNew,
          dadosDivShellNew: data,
          isLoading: false
        });
      })
      .catch(error => {
        this.setState({ error, isLoading: false });
      });
  }
  loadErrosDivulgacao() {
    var url = 'http://setot.tse.jus.br:9000/erros-divulgacao/';
    console.log(url);
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        this.setState({
          errosDivulgacaoOld: this.state.errosDivulgacaoNew,
          errosDivulgacaoNew: data,
          isLoading: false
        });
      })
      .catch(error => {
        this.setState({ error, isLoading: false });
      });
  }
  loadValidacaoArquivosDivulgacao() {
    var ambiente = this.state.ambiente;
    var eleicao = this.state.eleicaoSelecionada.cd;
    var ano = this.state.eleicaoSelecionada.ano;
    var url =
      'http://setot.tse.jus.br:9000/arquivo-indice/check-all/' +
      ano +
      '/' +
      ambiente +
      '/todas/' +
      eleicao;
    console.log(url);
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        this.setState({
          validacaoArquivosDiv: data,
          isLoading: false
        });
      })
      .catch(error => {
        this.setState({ error, isLoading: false });
      });
  }
  loadEleicoesCargoJSON(url) {
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        var atualizou = false;
        data.cand.sort(this.GetSortOrder('seq'));
        var eleicoes = this.state.eleicoes[data.carper];
        eleicoes.push(data);

        if (this.state.chkValidacoes) {
          this.validarJSON(url, data);
        }
        if (data.cdabr.toLowerCase() === this.state.abrangenciaSelecionada) {
          var eleicoesCarregadas = this.state.eleicoesCarregadas;

          for (var i = 0; i < eleicoesCarregadas.length; i++) {
            if (eleicoesCarregadas[i].carper === data.carper) {
              eleicoesCarregadas[i] = data;
              atualizou = true;
            }
          }
          if (!atualizou) {
            eleicoesCarregadas.push(data);
          }
        }
        
        this.state.isLoadingCargo[data.carper] = false;
        this.setState({ isLoading: false });
      })
      .catch(error => {
        this.setState({ error, isLoading: false });
      });
  }
  loadEleicoesJSON(url) {
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        if (this.state.eleicaoSelecionada.tp==="6" || this.state.eleicaoSelecionada.tp==="5") {
          data.resp.sort(this.GetSortOrder('seq'));
        } else {
          data.cand.sort(this.GetSortOrder('seq'));
        }
        var eleicoesCarregadas = this.state.eleicoesCarregadas;
        var eleicoes = this.state.eleicoes[data.carper];
        eleicoes.push(data);
        if (this.state.chkValidacoes) {
          this.validarJSON(url, data);
        }
        //if (data.cdabr.toLowerCase() === this.state.abrangenciaSelecionada) {
          
        if (this.state.eleicaoSelecionada.abrangenciasDisponiveis.includes(data.cdabr.toLowerCase())) {
          for (
            var i = 0;
            i < this.state.eleicaoSelecionada.abr[0].cp.length;
            i++
          ) {
            if (data.carper === this.state.eleicaoSelecionada.abr[0].cp[i].cd && this.state.abrangenciaSelecionada === data.cdabr.toLowerCase()) {
              eleicoesCarregadas.push(data);
            }
            console.log(data.carper+' - '+data.cdabr+' - '+data.ele+' - '+data.esae+' - '+data.md+' - '+data.tf);
          }
        }
        this.setState({ isLoading: false });
      })
      .catch(error => {
        this.setState({ error, isLoading: false });
      });
  }
  validarJSON(url, data) {
    const validacoes = {
      TOTAL_SECOES:
        'Total de seções é diferente de seções totalizadas + não totalizadas.',
      SECOES_TOTALIZACAO: 'Existe seção não totalizada e totalização final.',
      TOTAL_ELEITORADO:
        'Eleitorado total é diferente de eleitorado apurado + não apurado.',
      COMPARECIMENTO_VOTOS: 'Comparecimento é diferente de votos.',
      COMPARECIMENTO_ABSTENCAO:
        'Comparecimento + abstenção é diferente do eleitorado apurado.',
      NAO_EXISTEM_CANDIDATOS: 'Não existem votáveis.',
      TOTAL_VOTOS:
        'Total de votos é diferente de válidos + brancos + nulos + anulados.',
      VALIDOS_NOMINAIS_LEGENDA:
        'Total de válidos é diferente de nominais + legenda.',
      VOTOS_VALIDOS_CANDIDATOS:
        'O total de votos dos candidatos mais legenda é diferente dos válidos da eleição.',
      VOTOS_NOMINAIS_CANDIDATOS:
        'O total de votos dos candidatos é diferente dos votos nominais da eleição. ',
        ELEITORADO_SECOES_INSTALADAS:
        'e = esi + esni',
        ELEITORADO_COMPARECIMENTO:
        'e = c + a + esni'
    };
    var erro = {};
    var erros = this.state.erroValidacaoJSON;
    if (
      parseInt(data.s, 10) !==
      parseInt(data.st, 10) + parseInt(data.snt, 10)
    ) {
      erro = {
        codigoSituacao: 1,
        descricaoSituacao: validacoes.TOTAL_SECOES,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    if (parseInt(data.snt, 10) > 0 && data.tf === 's') {
      erro = {
        codigoSituacao: 2,
        descricaoSituacao: validacoes.SECOES_TOTALIZACAO,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    if (
      parseInt(data.e, 10) !==
      parseInt(data.ea, 10) + parseInt(data.ena, 10)
    ) {
      erro = {
        codigoSituacao: 3,
        descricaoSituacao: validacoes.TOTAL_ELEITORADO,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    if (
      parseInt(data.ea, 10) !==
      parseInt(data.esi, 10) + parseInt(data.esni, 10)
    ) {
      erro = {
        codigoSituacao: 11,
        descricaoSituacao: validacoes.ELEITORADO_SECOES_INSTALADAS,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    if (
      parseInt(data.ea, 10) !==
      parseInt(data.c, 10) + parseInt(data.a, 10) + parseInt(data.esni, 10)
    ) {
      erro = {
        codigoSituacao: 12,
        descricaoSituacao: validacoes.ELEITORADO_COMPARECIMENTO,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    if (parseInt(data.c, 10) !== parseInt(data.tv, 10) && data.carper !== '5') {
      erro = {
        codigoSituacao: 4,
        descricaoSituacao: validacoes.COMPARECIMENTO_VOTOS,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    if (parseInt(data.ea, 10) !== parseInt(data.c, 10) + parseInt(data.a, 10)) {
      erro = {
        codigoSituacao: 5,
        descricaoSituacao: validacoes.COMPARECIMENTO_ABSTENCAO,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    if (this.state.eleicaoSelecionada.tp!=="5" && this.state.eleicaoSelecionada.tp!=="6" &&data.cand.length < 1) {
      erro = {
        codigoSituacao: 6,
        descricaoSituacao: validacoes.NAO_EXISTEM_CANDIDATOS,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    if ((this.state.eleicaoSelecionada.tp==="5" || this.state.eleicaoSelecionada.tp==="6") &&data.resp.length < 1) {
      erro = {
        codigoSituacao: 6,
        descricaoSituacao: validacoes.NAO_EXISTEM_CANDIDATOS,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }
    //tv= vb+ tvn(vn+vnt) +  vp + vv(vnom+vl)+ van + vansj
    if (
      parseInt(data.tv, 10) !==
        parseInt(data.vb, 10) +
        parseInt(data.tvn, 10) +
        parseInt(data.vp, 10) +
        parseInt(data.vv, 10) +
        parseInt(data.van, 10)+
        parseInt(data.vansj, 10)
    ) {
      erro = {
        codigoSituacao: 7,
        descricaoSituacao: validacoes.TOTAL_VOTOS,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }

    if (//incluir nulos técnicos na validação pois eles não aparecem na lista
      parseInt(data.vv, 10) !== parseInt(data.vnt, 10) +
      parseInt(data.vnom, 10) + parseInt(data.vl===undefined?0:data.vl, 10)
    ) {
      erro = {
        codigoSituacao: 8,
        descricaoSituacao: validacoes.VALIDOS_NOMINAIS_LEGENDA,
        dataArquivo: data.dt + ' ' + data.ht,
        caminhoArquivo: url
      };
      erros.push(erro);
    }

    if (this.state.eleicaoSelecionada.tp!=="6" && data.cand.length > 0) {
      var totalVotosCandidatos = 0;
      for (var i = 0; i < data.cand.length; i++) {
        if (data.cand[i].dvt=== 'Válido') {
        totalVotosCandidatos =
          totalVotosCandidatos + parseInt(data.cand[i].vap, 10);
        }
      }
     // console.log(parseInt(totalVotosCandidatos,10)+' '+parseInt(data.vl===undefined?0:data.vl, 10)+' '+parseInt(data.vv, 10));
      if (
        parseInt(data.vv, 10) !==
          totalVotosCandidatos + parseInt(data.vl===undefined?0:data.vl, 10) &&
        data.dv === 's'
      ) {
        erro = {
          codigoSituacao: 9,
          descricaoSituacao: validacoes.VOTOS_VALIDOS_CANDIDATOS,
          dataArquivo: data.dt + ' ' + data.ht,
          caminhoArquivo: url
        };
        erros.push(erro);
      }
      if (parseInt(data.vnom, 10) !== totalVotosCandidatos && data.dv === 's') {
        erro = {
          codigoSituacao: 10,
          descricaoSituacao: validacoes.VOTOS_NOMINAIS_CANDIDATOS,
          dataArquivo: data.dt + ' ' + data.ht,
          caminhoArquivo: url
        };
        erros.push(erro);
      }
    }
  }
  sumArray(a, b) {
    var c = [];
    for (var i = 0; i < Math.max(a.length, b.length); i++) {
      c.push((parseInt(a[i], 10) || 0) + (parseInt(b[i], 10) || 0));
    }
    return c;
  }
  arrayRemove(arr, value) {
    return arr.filter(function(ele) {
      return ele.apuracao.length !== value;
    });
  }
  validarEvolucao(url, data) {
    const validacoes = {
      TOTAL_PARCIAIS_DIFERENTE:
        'Evolução: A quantidade de parciais é diferente entre candidatos.',
      SOMA_TOTVOT_PARCIAIS_DIFERENTE_DE_TOTVAL:
        'Evolução: A soma dos votos parciais dos candidatos é diferente do total de válidos.'
    };
    var erro = {};
    var erros = this.state.erroValidacaoJSON;
    var totalDeParciais = 0;
    var totVotParciais = [],
      candidatosTotVotParciais = [];
    var aptos = this.arrayRemove(data.cargo.candidato, 0);

    for (var i = 0; i < aptos.length; i++) {
      aptos[i].apuracao.sort(this.GetSortOrderDataHora('datApu', 'horApu'));
      if (
        totalDeParciais > 0 &&
        aptos[i].apuracao.length > 0 &&
        totalDeParciais !== aptos[i].apuracao.length
      ) {
        erro = {
          codigoSituacao: 101,
          descricaoSituacao: validacoes.TOTAL_PARCIAIS_DIFERENTE,
          dataArquivo: i + ': ' + data.datGer + ' ' + data.horGer,
          caminhoArquivo: url
        };
        erros.push(erro);
      }
      totalDeParciais = aptos[i].apuracao.length;
      totVotParciais = [];
      for (var k = 0; k < aptos[i].apuracao.length; k++) {
        totVotParciais.push(aptos[i].apuracao[k].totVot);
      }
      candidatosTotVotParciais.push(totVotParciais);
      // console.log(totalDeParciais);
    }
    //console.log(y);
    var somaArray = candidatosTotVotParciais[0];
    for (i = 1; i < candidatosTotVotParciais.length; i++) {
      somaArray = this.sumArray(somaArray, candidatosTotVotParciais[i]);
    }

    for (i = 0; i < aptos.length; i++) {
      for (k = 0; k < aptos[i].apuracao.length; k++) {
        // console.log(parseInt(aptos[i].apuracao[k].votVal, 10)+"==="+  parseInt(somaArray[k], 10));
        if (
          parseInt(aptos[i].apuracao[k].votVal, 10) !==
          parseInt(somaArray[k], 10)
        ) {
          //  console.log(k +"   " + aptos[i].apuracao[k].horApu)
          erro = {
            codigoSituacao: 102,
            descricaoSituacao:
              validacoes.SOMA_TOTVOT_PARCIAIS_DIFERENTE_DE_TOTVAL,
            dataArquivo: data.datGer + ' ' + data.horGer,
            caminhoArquivo: url
          };
        }
      }
    }
    if (erro.codigoSituacao === 102) {
      erros.push(erro);
    }
  }
  loadEvolucao(url) {
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        var evolucao = this.state.evolucao;
        evolucao.push(data);
        if (this.state.chkValidacoes) {
          this.validarEvolucao(url, data);
        }
        this.setState({ evolucao: evolucao, isLoading: false });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }

  loadEleicao(url) {
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        var eleicoesCarregadas = this.state.eleicoesCarregadas;
        eleicoesCarregadas.push(data);
        if (this.state.chkValidacoes) {
          this.validarJSON(url, data);
        }
        this.setState({
          eleicoesCarregadas: eleicoesCarregadas,
          isLoading: false
        });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }

  loadArquivoConfiguracaoEleicao(ambiente) {
    var arquivo =
      this.state.url +
      ambiente +
      '/comum/config/ele-c.json';

    console.log(arquivo);
    
    fetch(arquivo + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        data.pl.sort(this.GetSortOrderData('dt'));
        //console.log(data);
        this.setState({
          eleicoesConfiguradas: data,
          isLoading: false,
          configuracaoEleicao: data
        });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }
  carregarArquivosConfiguracaoEleicao(ambiente) {
    this.setState({ eleicoesDisponiveis: [] });
    this.loadArquivoConfiguracaoEleicao(ambiente);
  }
  loadValidacaoArquivoDeIndice(url) {
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        this.setState({
          arquivoDeIndice: data,
          isLoading: false
        });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }

  carregaValidacaoArquivoIndice(abrangencia, eleicao) {
    var ambiente = this.state.ambiente;
    // var eleicao = this.state.eleicaoSelecionada.cd;
    // var ano = this.state.eleicaoSelecionada.ano;
    //var abrangencia = this.state.abrangenciaSelecionada;
    var arquivo = '';
    arquivo =
      'http://setot.tse.jus.br:9000/arquivo-indice/check/' +
      eleicao.ano +
      '/' +
      ambiente +
      '/' +
      abrangencia +
      '/' +
      eleicao.cd;
    console.log(arquivo);
    this.loadValidacaoArquivoDeIndice(arquivo);
  }
  carregaEvolucao(abrangencia, eleicao, cargo) {
    var ambiente = this.state.ambiente;
    //var eleicao = this.state.eleicaoSelecionada;

    var ano = eleicao.ano;
    var arquivo = '';
    cargo = 'c' + (parseInt(cargo, 10) + 10000).toString().slice(-4);
    arquivo =
      this.state.url +
      ano +
      '/divulgacao/' +
      ambiente +
      '/' +
      eleicao.cd +
      '/dados/' +
      abrangencia +
      '/' +
      abrangencia +
      '-' +
      cargo +
      '-e00' +
      (parseInt(eleicao.cd, 10) + 1000000).toString().slice(-4) +
      '-tw.js';
    console.log(arquivo);
    this.loadEvolucao(arquivo);
  }
  carregaEvolucaoMunicipal(abrangencia, muncipio, eleicao, cargo) {
    var ambiente = this.state.ambiente;
    //var eleicao = this.state.eleicaoSelecionada;

    var ano = eleicao.ano;
    var arquivo = '';
    cargo = 'c' + (parseInt(cargo, 10) + 10000).toString().slice(-4);
    arquivo =
      this.state.url +
      ano +
      '/divulgacao/' +
      ambiente +
      '/' +
      eleicao.cd +
      '/dados/' +
      abrangencia +
      '/' +
      abrangencia +
      muncipio +
      '-' +
      cargo +
      '-e00' +
      (parseInt(eleicao.cd, 10) + 1000000).toString().slice(-4) +
      '-tw.js';
    console.log(arquivo);
    this.loadEvolucao(arquivo);
  }
  loadValidacaoArquivosXML(url) {
    fetch(url + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        this.setState({
          erroValidacaoXML: data,
          isLoading: false
        });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }
  carregaValidacaoArquivosXML(abrangencia, eleicao) {
    var ambiente = this.state.ambiente;
    // var eleicao = this.state.eleicaoSelecionada.cd;
    //var ano = this.state.eleicaoSelecionada.ano;
    var arquivo = '';
    arquivo =
      'http://setot.tse.jus.br:9000/arquivo-divulgacao/check/' +
      eleicao.ano +
      '/' +
      ambiente +
      '/' +
      abrangencia +
      '/' +
      eleicao.cd;
    console.log(arquivo);
    this.loadValidacaoArquivosXML(arquivo);
  }
  carregaArquivosResultadoPorPleito(pleito) {
    var ambiente = this.state.ambiente;
    var eleicao = '';
    var abrangencia = '';
    var ano = '';
    var cargo = '';
    var arquivo = '';
    this.setState({ eleicoesCarregadas: [] });

    for (
      var i = 0;
      this.state.eleicoesConfiguradas[pleito] !== undefined &&
      i < this.state.eleicoesConfiguradas[pleito].length;
      i++
    ) {
      eleicao = this.state.eleicoesConfiguradas[pleito][i];
      ano = eleicao.ano;

      for (var j = 0; j < eleicao.cdabr.length; j++) {
        abrangencia = eleicao.cdabr[j].toLowerCase();

        for (var k = 0; k < eleicao.cargos.length; k++) {
          cargo =
            abrangencia === 'df' && eleicao.cargos[k].cd === '7'
              ? 8
              : parseInt(eleicao.cargos[k].cd, 10);
          cargo = 'c' + (cargo + 10000).toString().slice(-4);

          arquivo =
            this.state.url +
            ano +
            '/divulgacao/' +
            ambiente +
            '/' +
            eleicao.cd +
            '/dadosdivweb/' +
            abrangencia +
            '/' +
            abrangencia +
            '-' +
            cargo +
            '-e00' +
            eleicao.cd +
            '-w.js';
          console.log(arquivo);
          this.loadEleicoesJSON(arquivo);
        }
      }
    }
  }
  carregaArquivosResultadoPorCargo(idcargo) {
    var ambiente = this.state.ambiente;
    var abrangencia = this.state.abrangenciaSelecionada;
    var eleicao = this.state.eleicaoSelecionada;
    var ano = eleicao.ano;
    var arquivo = '';
    this.state.eleicoes[eleicao.cargos[idcargo].cd] = [];
    var photoUrl =
      this.state.url +
      ano +
      '/divulgacao/' +
      ambiente +
      '/' +
      eleicao.cd +
      '/fotos/';
    this.setState({ photoUrl: photoUrl });
    if (
      eleicao.cargos[idcargo].cd === '1' ||
      eleicao.cargos[idcargo].cd === '3' ||
      eleicao.cargos[idcargo].cd === '5'
    ) {
      this.carregaEvolucao(abrangencia, eleicao, eleicao.cargos[idcargo].cd);
    }
    for (var j = 0; j < eleicao.cdabr.length; j++) {
      abrangencia = eleicao.cdabr[j].toLowerCase();
      var cargo =
        abrangencia === 'df' && eleicao.cargos[idcargo].cd === '7'
          ? 8
          : parseInt(eleicao.cargos[idcargo].cd, 10);
      cargo = 'c' + (cargo + 10000).toString().slice(-4);

      arquivo =
        this.state.url +
        ano +
        '/divulgacao/' +
        ambiente +
        '/' +
        eleicao.cd +
        '/dadosdivweb/' +
        abrangencia +
        '/' +
        abrangencia +
        '-' +
        cargo +
        '-e' +
        (parseInt(eleicao.cd, 10) + 1000000).toString().slice(-6) +
        '-w.js';
      console.log(arquivo);
      this.loadEleicoesCargoJSON(arquivo);
    }
  }
  carregaArquivosResultadoPorEleicao(abrangencia, eleicao) {
    var ambiente = this.state.ambiente;
    var ano = this.state.configuracaoEleicao.c;
    var cargo = '';
    var cargos = eleicao.abr[0].cp ;
    var arquivo = '';
    console.log(abrangencia);
    this.setState({ eleicoesCarregadas: [] });
    var photoUrl =
      this.state.url +
      ambiente + '/' +
      ano + '/' +
      eleicao.cd +
      '/fotos/';
    this.setState({ photoUrl: photoUrl });

    for (var j = 0; j < eleicao.abrangenciasDisponiveis.length; j++) {
      abrangencia = eleicao.abrangenciasDisponiveis[j].toLowerCase();
      
      var cargocorreto = true;
      for (var k = 0; k < cargos.length; k++) {
        cargo = parseInt(cargos[k].cd, 10);
        
        cargocorreto =  (cargo === '8' && abrangencia !=='df') || ( cargo === '7' && abrangencia === 'df') ? false:true;

        cargo = 'c' + (cargo + 10000).toString().slice(-4);

        arquivo =
          this.state.url +
          ambiente + '/' +
          ano + '/' +
          eleicao.cd +
          '/dados-simplificados/' +
          abrangencia+ '/' +
          abrangencia+
          '-' +
          cargo +
          '-e' +
          (parseInt(eleicao.cd, 10) + 1000000).toString().slice(-6) +
          '-r.json';

          if(cargocorreto) {
            console.log(arquivo);
            this.loadEleicoesJSON(arquivo);
          }
      }
      //this.carregaArquivoAcompanhamentoUF(eleicao,abrangencia);
    }
    this.carregaArquivoAcompanhamentoBR(eleicao);
  }

  carregaArquivoResultadoMunicipio(municipio,uf) {
    this.setState({ municipioSelecionado: municipio  });
    var ambiente = this.state.ambiente;
    var ano = this.state.configuracaoEleicao.c;
    var cargo = '';
    var cargos = this.state.eleicaoSelecionada.abr[0].cp;
    var arquivo = '';
    var eleicao = this.state.eleicaoSelecionada;
    var abrangencia = uf !== undefined ? uf : this.state.abrangenciaSelecionada;
    console.log(municipio);
    this.setState({ eleicoesCarregadas: [] });
    var photoUrl =
      this.state.url +
      ambiente + '/' +
      ano + '/' +
      eleicao.cd +
      '/fotos/' ;
    this.setState({ photoUrl: photoUrl });
    for (var i = 0; i < cargos.length; i++) {
      cargo =
        'c' + (parseInt(cargos[i].cd, 10) + 10000).toString().slice(-4);
      arquivo =
        this.state.url +
        ambiente + '/' +
        ano + '/' +
        eleicao.cd +
        '/dados-simplificados/' +
        abrangencia+ '/' +
        abrangencia+
        municipio +
        '-' +
        cargo +
        '-e' +
        (parseInt(eleicao.cd, 10) + 1000000).toString().slice(-6) +
        '-r.json';
      console.log(arquivo);
/*      if (eleicao.cargos[i].cd === '11') {
        this.carregaEvolucaoMunicipal(
          abrangencia,
          municipio,
          eleicao,
          eleicao.cargos[i].cd
        );
      }*/
      this.loadEleicao(arquivo);
    }
  }

  carregaArquivoAcompanhamentoUF(eleicao,abrangencia) {
    var ambiente = this.state.ambiente;
    var ano = this.state.configuracaoEleicao.c;
    var arquivo = '';
    arquivo =
      this.state.url +
      ambiente +'/' +
      ano + '/' +
      eleicao.cd +
      '/dados/' +
      abrangencia +
      '/' + abrangencia+ '-e'+
      (parseInt(eleicao.cd, 10) + 1000000).toString().slice(-6) +
      '-ab.json';
    console.log(arquivo);
    this.setState({ acompanhamentoUF:[] });
    fetch(arquivo + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        this.setState({ acompanhamentoUF:data, isLoading: false });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }
  carregaArquivoAcompanhamentoBR(eleicao) {
    var ambiente = this.state.ambiente;
    var ano = this.state.configuracaoEleicao.c;
    var arquivo =
      this.state.url +
      ambiente +'/' +
      ano + '/' +
      eleicao.cd +
      '/dados/' +
      'br/br-e'+
      (parseInt(eleicao.cd, 10) + 1000000).toString().slice(-6) +
      '-ab.json';
    console.log(arquivo);
    this.setState({ acompanhamentoBR:[] });
    fetch(arquivo + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        this.setState({ acompanhamentoBR:data, isLoading: false });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }
  carregaArquivoConfiguracaoMunicipios(eleicao) {
    var ambiente = this.state.ambiente;
    var ano = this.state.configuracaoEleicao.c;
    var arquivo = '';
    arquivo =
      this.state.url +
      ambiente +'/' +
      ano + '/' +
      eleicao.cd +
      '/config' +
      '/mun-e' +
      (parseInt(eleicao.cd, 10) + 1000000).toString().slice(-6) +
      '-cm.json';
    console.log(arquivo);
    this.setState({ municipiosConfigurados: [], abrangenciasDisponiveis: [] });
    fetch(arquivo + '?v=' + Date.now())
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong ...');
        }
      })
      .then(data => {
        if (data.abr.length === 1 && data.abr[0].mu.length === 1) {
          this.setState({ municipioSelecionado: data.abr[0].mu[0].cd });
          this.carregaArquivoResultadoMunicipio(data.abr[0].mu[0].cd,data.abr[0].cd.toLowerCase());
        }
        var abrangenciasDisponiveis = [];
        if (eleicao.tp==='8' || eleicao.tp==='9'|| eleicao.tp==='5'){
             abrangenciasDisponiveis.push('br');
        }
        for (var i = 0; i < data.abr.length; i++) {
            abrangenciasDisponiveis.push(data.abr[i].cd.toLowerCase());
        }
        var eleicaoSelecionada=this.state.eleicaoSelecionada;
        eleicaoSelecionada.abrangenciasDisponiveis = abrangenciasDisponiveis;
        if (eleicao.tp === '3' || eleicao.tp === '4' || eleicao.tp === '7') {
          document.getElementById('comboMunicipio').style.display = 'block'; //className="collapse show";
          document.getElementById('comboMunicipio').value = data.abr[0].mu[0].cd;
        } else {
          this.carregaArquivosResultadoPorEleicao(abrangenciasDisponiveis[0],eleicaoSelecionada);
        }
        this.setState({ eleicaoSelecionada: eleicaoSelecionada, municipiosConfigurados: data,abrangenciasDisponiveis:abrangenciasDisponiveis, abrangenciaSelecionada:abrangenciasDisponiveis[0], isLoading: false });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }
  componentDidMount() {
    this.setState({ isLoading: true });
    this.carregarArquivosConfiguracaoEleicao(this.state.ambiente);
    if (this.state.chkDivulgaShell) {
      this.loadDivulgaShell();
      this.loadDivulgaShell();
    }
    this.setState({ dadosDivShellOld: this.state.dadosDivShellNew });
    //this.loadErrosDivulgacao();
    this.setState({ errosDivulgacaoOld: this.state.errosDivulgacaoNew });
    if (this.state.chkDivulgaShell) {
      this.intervalId = setInterval(() => {
        this.loadDivulgaShell();
        //this.loadErrosDivulgacao();
      }, 35000);
    }
  }
  componentWillUnmount() {
    clearInterval(this.intervalId);
  }

  GetSortOrderData(prop) {
    return function(a, b) {
      var dia = a[prop].split('/')[0];
      var mes = a[prop].split('/')[1];
      var ano = a[prop].split('/')[2];
      var data1 =
        ano + '-' + ('0' + mes).slice(-2) + '-' + ('0' + dia).slice(-2);

      dia = b[prop].split('/')[0];
      mes = b[prop].split('/')[1];
      ano = b[prop].split('/')[2];
      var data2 =
        ano + '-' + ('0' + mes).slice(-2) + '-' + ('0' + dia).slice(-2);

      if (new Date(data1) > new Date(data2)) {
        return -1;
      } else if (new Date(data1) < new Date(data2)) {
        return 1;
      }
      return 0;
    };
  }
  GetSortOrderAsc(prop) {
    return function(a, b) {
      if (parseInt(a[prop], 10) > parseInt(b[prop], 10)) {
        return 1;
      } else if (parseInt(a[prop], 10) < parseInt(b[prop], 10)) {
        return -1;
      }
      return 0;
    };
  }
  GetSortOrderDesc(prop) {
    return function(a, b) {
      if (parseInt(a[prop], 10) > parseInt(b[prop], 10)) {
        return -1;
      } else if (parseInt(a[prop], 10) < parseInt(b[prop], 10)) {
        return 1;
      }
      return 0;
    };
  }
  GetSortOrderStr(prop) {
    return function(a, b) {
      if (a[prop] > b[prop]) {
        return 1;
      } else if (a[prop] < b[prop]) {
        return -1;
      }
      return 0;
    };
  }
  GetSortOrderDataHora(propdt, propht) {
    return function(a, b) {
      var dia = a[propdt].split('/')[0];
      var mes = a[propdt].split('/')[1];
      var ano = a[propdt].split('/')[2];

      var hora = a[propht].split(':')[0];
      var minuto = a[propht].split(':')[1];
      var segundo = a[propht].split(':')[2];

      var data1 = new Date(ano, mes, dia, hora, minuto, segundo);
      //ano + '-' + ('0' + mes).slice(-2) + '-' + ('0' + dia).slice(-2);

      dia = b[propdt].split('/')[0];
      mes = b[propdt].split('/')[1];
      ano = b[propdt].split('/')[2];

      hora = b[propht].split(':')[0];
      minuto = b[propht].split(':')[1];
      segundo = b[propht].split(':')[2];

      var data2 = new Date(ano, mes, dia, hora, minuto, segundo);
      //ano + '-' + ('0' + mes).slice(-2) + '-' + ('0' + dia).slice(-2);

      if (data1 > data2) {
        return 1;
      } else if (data1 < data2) {
        return -1;
      }
      return 0;
    };
  }
  renderComboEleicao() {
    var rows = [];
    var hoje = new Date();
    var dataLimite = new Date(new Date().setDate(hoje.getDate() - 30));
    var dataEleicao, dt;
    var eleicoesConfiguradas = this.state.configuracaoEleicao.pl;
    for (var x in eleicoesConfiguradas) {
      dt = eleicoesConfiguradas[x].dt;
      dataEleicao = new Date(
        dt.split('/')[2],
        dt.split('/')[1] - 1,
        dt.split('/')[0]
      );
      for (var i = 0; i < eleicoesConfiguradas[x].e.length; i++) {

        if (this.state.mostrarEleicoesRecentes) {
          if (dataEleicao > dataLimite) {
            rows.push(
              <option
                value={x + '-' + i}
                key={eleicoesConfiguradas[x].e[i].cd}
              >
                {eleicoesConfiguradas[x].e[i].cd} -{' '}
                {eleicoesConfiguradas[x].dt} -{' '}
                {eleicoesConfiguradas[x].e[i].nm.replace('&#186;','º')}
              </option>
            );
          }
        } else {
          rows.push(
            <option
              value={x + '-' + i}
              key={eleicoesConfiguradas[x].e[i].cd}
            >
              {eleicoesConfiguradas[x].e[i].cd} -{' '}
              {eleicoesConfiguradas[x].dt} -{' '}
              {eleicoesConfiguradas[x].e[i].nm.replace('&#186;','º')}
            </option>
          );
        }
      }
    }
    return rows;
  }
  renderComboEleicaoTypeAhead() {
    var rows = [];
    for (var x in this.state.eleicoesConfiguradas) {
      for (var i = 0; i < this.state.eleicoesConfiguradas[x].length; i++) {
        rows.push(
          this.state.eleicoesConfiguradas[x][i].cd +
            ' / ' +
            this.state.eleicoesConfiguradas[x][i].nm
        );
      }
    }
    return rows;
  }
  renderComboMunicipio() {
    var getObjectByValue = function(array, key, value) {
      return array.filter(function(object) {
        return object[key] === value;
      });
    };
    var rows = [];
    if (this.state.municipiosConfigurados.abr !== undefined) {
      var abr = getObjectByValue(this.state.municipiosConfigurados.abr, 'cd', this.state.abrangenciaSelecionada.toUpperCase());
      
      if(abr[0]!==undefined && abr[0].mu!==undefined)
      {
     //   console.log(abr[0]);
      for (var i = 0; i < abr[0].mu.length; i++) {
        rows.push(
          <option value={abr[0].mu[i].cd} key={i}>
            {abr[0].mu[i].cd} -{' '}
            {abr[0].mu[i].nm}
          </option>
        );
      }
    }
    }
    return rows;
  }
  renderTabCargo() {
    var rows = [];
    if (this.state.eleicaoSelecionada !== undefined) {
      this.state.eleicaoSelecionada.abr[0].cp.sort(this.GetSortOrderAsc('cd'));
      var id, aria, href, classTab, classSync;
      for (var i = 0; i < this.state.eleicaoSelecionada.abr[0].cp.length; i++) {
        id = 'nav-tab-' + i;
        aria = 'nav-' + i;
        href = '#' + aria;
        classTab =
          i === 0 ? 'nav-item nav-link show active' : 'nav-item nav-link';
        classSync = this.state.isLoadingCargo[
          parseInt(this.state.eleicaoSelecionada.abr[0].cp[i].cd, 10)
        ]
          ? 'fas fa-sync-alt fa-spin'
          : 'fas fa-sync-alt';
          if((this.state.eleicaoSelecionada.abr[0].cp[i].cd !== '8')){
        rows.push(
          <a
            className={classTab}
            id={id}
            key={id}
            data-toggle="tab"
            href={href}
            role="tab"
            aria-controls={aria}
          >
            {this.state.eleicaoSelecionada.abr[0].cp[i].cd === '7' &&
            this.state.abrangenciaSelecionada === 'df'
              ? 'Deputado Distrital'
              : this.state.eleicaoSelecionada.abr[0].cp[i].ds}
            &nbsp;{' '}
            <span
              className="button"
              style={{ fontSize: '12px', color: 'Dodgerblue' }}
              id={this.state.eleicaoSelecionada.abr[0].cp[i].cd}
              onClick={this.handleClickCargo}
            >
              <span className={classSync} />
            </span>
          </a>
        );
      }}
    }
    return rows;
  }
  renderVotacao() {
    var rows = [];
    if (
      this.state.eleicaoSelecionada !== undefined &&
      this.state.eleicoesCarregadas.length > 0
    ) {
      this.state.eleicoesCarregadas.sort(this.GetSortOrderAsc('carper'));
      var id, aria, classTabPanel, eleicoesFlag;
      for (var i = 0; i < this.state.eleicoesCarregadas.length; i++) {
        id = 'nav-' + i;
        aria = 'nav-tab-' + i;
        classTabPanel = i === 0 ? 'tab-pane fade show active' : 'tab-pane fade';
        eleicoesFlag = this.state.eleicoes[
          this.state.eleicoesCarregadas[i].carper
        ];
        rows.push(
          <div
            className={classTabPanel}
            id={id}
            key={i}
            role="tabpanel"
            aria-labelledby={aria}
          >
            <Painel
              className="painel"
              cargo={this.state.cargo}
              cdeleicao={this.state.eleicaoSelecionada.cd}
              nmeleicao={this.state.eleicaoSelecionada.nm}
              vt={this.state.eleicoesCarregadas[i]}
              eleicoesFlag={eleicoesFlag}
              evolucao={this.state.evolucao}
              photoUrl={this.state.photoUrl}
              uf={this.state.abrangenciaSelecionada}
              mostrarFotos={this.state.mostrarFotos}
              tipoEleicao={this.state.eleicaoSelecionada.tp}
            />
          </div>
        );
      }
    }
    return rows;
  }
  renderTabArquivoDeIndice() {
    var rows = [];
    rows.push(
      <a
        className="nav-item nav-link"
        id="nav-tab-indice"
        key="nav-tab-indice"
        data-toggle="tab"
        href="#nav-indice"
        role="tab"
        aria-controls="nav-indice"
      >
        Validação Índice{' '}
        <span className="badge badge-danger small">
          {this.state.arquivoDeIndice.length}
        </span>
      </a>
    );
    return rows;
  }
  geraMapaIndice() {
    var codigoSituacao = 0,
      mapaIndice = {};
    for (var i = 0; i < this.state.arquivoDeIndice.length; i++) {
      codigoSituacao = parseInt(
        this.state.arquivoDeIndice[i].codigoSituacao,
        10
      );
      if (mapaIndice[codigoSituacao] === undefined) {
        mapaIndice[codigoSituacao] = {
          arquivos: [],
          descricaoSituacao: this.state.arquivoDeIndice[i].descricaoSituacao
        };
      }
      mapaIndice[codigoSituacao].arquivos.push(this.state.arquivoDeIndice[i]);
    }
    return mapaIndice;
  }
  renderIndice() {
    var rows = [];
    var indice = this.geraMapaIndice();
    for (var key in indice) {
      if (indice.hasOwnProperty(key)) {
        rows.push(
          <Indice
            key={key}
            codigoSituacao={key}
            descricaoSituacao={indice[key].descricaoSituacao}
            arquivos={indice[key].arquivos}
            onRegerarIndiceClick={this.handleRegerarIndice}
          />
        );
      }
    }
    return rows;
  }
  geraMapaErroJSON() {
    var codigoSituacao = 0,
      mapaErroJSON = {};
    for (var i = 0; i < this.state.erroValidacaoJSON.length; i++) {
      codigoSituacao = parseInt(
        this.state.erroValidacaoJSON[i].codigoSituacao,
        10
      );
      if (mapaErroJSON[codigoSituacao] === undefined) {
        mapaErroJSON[codigoSituacao] = {
          arquivos: [],
          descricaoSituacao: this.state.erroValidacaoJSON[i].descricaoSituacao
        };
      }
      mapaErroJSON[codigoSituacao].arquivos.push(
        this.state.erroValidacaoJSON[i]
      );
    }
    return mapaErroJSON;
  }
  renderTabValidacaoJSON() {
    var rows = [];
    rows.push(
      <a
        className="nav-item nav-link"
        id="nav-tab-validacaojson"
        key="nav-tab-validacaojson"
        data-toggle="tab"
        href="#nav-validacaojson"
        role="tab"
        aria-controls="nav-validacaojson"
      >
        Validação JSON{' '}
        <span className="badge badge-danger small">
          {this.state.erroValidacaoJSON.length}
        </span>
      </a>
    );
    return rows;
  }
  renderLogValidacaoJSON() {
    var rows = [];
    var mapa = this.geraMapaErroJSON();
    for (var key in mapa) {
      if (mapa.hasOwnProperty(key)) {
        rows.push(
          <Validacao
            key={key}
            codigoSituacao={key}
            descricaoSituacao={mapa[key].descricaoSituacao}
            arquivos={mapa[key].arquivos}
          />
        );
      }
    }
    return rows;
  }
  geraMapaErroXML() {
    var codigoSituacao = 0,
      mapaErroXML = {},
      erroValidacao = this.state.erroValidacaoXML;
    for (var i = 0; i < erroValidacao.length; i++) {
      codigoSituacao = parseInt(erroValidacao[i].codigoSituacao, 10);
      if (mapaErroXML[codigoSituacao] === undefined) {
        mapaErroXML[codigoSituacao] = {
          arquivos: [],
          descricaoSituacao: erroValidacao[i].descricaoSituacao
        };
      }
      mapaErroXML[codigoSituacao].arquivos.push(erroValidacao[i]);
    }
    return mapaErroXML;
  }
  renderTabValidacaoXML() {
    var rows = [];
    rows.push(
      <a
        className="nav-item nav-link"
        id="nav-tab-validacaoxml"
        key="nav-tab-validacaoxml"
        data-toggle="tab"
        href="#nav-validacaoxml"
        role="tab"
        aria-controls="nav-validacaoxml"
      >
        Validação XML{' '}
        <span className="badge badge-danger small">
          {this.state.erroValidacaoXML.length}
        </span>
      </a>
    );
    return rows;
  }
  renderLogValidacaoXML() {
    var rows = [];
    var mapa = this.geraMapaErroXML();
    for (var key in mapa) {
      if (mapa.hasOwnProperty(key)) {
        rows.push(
          <Validacao
            key={key}
            codigoSituacao={key}
            descricaoSituacao={mapa[key].descricaoSituacao}
            arquivos={mapa[key].arquivos}
          />
        );
      }
    }
    return rows;
  }
  renderTabValidacaoArquivosDiv() {
    var rows = [];
    rows.push(
      <a
        className="nav-item nav-link"
        id="nav-tab-validacaoarquivosdiv"
        key="nav-tab-validacaoarquivosdiv"
        data-toggle="tab"
        href="#nav-validacaoarquivosdiv"
        role="tab"
        aria-controls="nav-validacaoarquivosdiv"
      >
        Validação Arquivos{' '}
        <span className="badge badge-danger small">
          {this.state.validacaoArquivosDiv.length}
        </span>
      </a>
    );
    return rows;
  }
  GetSortOrder(prop) {
    return function(a, b) {
      if (parseInt(a[prop], 10) > parseInt(b[prop], 10)) {
        return 1;
      } else if (parseInt(a[prop], 10) < parseInt(b[prop], 10)) {
        return -1;
      }
      return 0;
    };
  }
  renderErrosDivulgacao() {
    var rows = [];
    var errosDivulgacaoNew = this.state.errosDivulgacaoNew;
    var errosDivulgacaoOld = this.state.errosDivulgacaoOld;
    var classErroDiv10min, classErroDiv20min;
    if (errosDivulgacaoNew !== undefined) {
      for (
        var i = 0;
        i < errosDivulgacaoNew.length && i < errosDivulgacaoOld.length;
        i++
      ) {
        classErroDiv10min =
          parseInt(errosDivulgacaoNew[i].quantidadeErrosUltimos10min, 10) > 0
            ? ' text-danger'
            : '';
        classErroDiv20min =
          parseInt(errosDivulgacaoNew[i].quantidadeErrosUltimos20min, 10) > 0
            ? ' text-danger'
            : '';
        rows.push(
          <tr key={i}>
            <td className="p-0">{errosDivulgacaoNew[i].host}</td>
            <td className={'p-0 ' + classErroDiv10min}>
              {errosDivulgacaoNew[i].quantidadeErrosUltimos10min !==
              errosDivulgacaoOld[i].quantidadeErrosUltimos10min ? (
                <strong>
                  {' '}
                  {errosDivulgacaoNew[i].quantidadeErrosUltimos10min}{' '}
                </strong>
              ) : (
                errosDivulgacaoOld[i].quantidadeErrosUltimos10min
              )}
            </td>
            <td className={'p-0 ' + classErroDiv20min}>
              {errosDivulgacaoNew[i].quantidadeErrosUltimos20min !==
              errosDivulgacaoOld[i].quantidadeErrosUltimos20min ? (
                <strong>
                  {' '}
                  {errosDivulgacaoNew[i].quantidadeErrosUltimos20min}{' '}
                </strong>
              ) : (
                errosDivulgacaoOld[i].quantidadeErrosUltimos20min
              )}
            </td>
          </tr>
        );
      }
    }
    return rows;
  }
  renderUFsComBloqueioDivulgacao() {
    var dadosDivShellNew = this.state.dadosDivShellNew;
    var ufsbloqueadas = '';
    for (var i = 0; i < dadosDivShellNew.length; i++) {
      if (dadosDivShellNew[i].bloqueioDivulgacao !== '-') {
        ufsbloqueadas =
          ufsbloqueadas + dadosDivShellNew[i].uf.substring(0, 2) + ', ';
      }
    }
    return ufsbloqueadas.substring(0, ufsbloqueadas.length - 2);
  }
  renderUFsNaoTotalizadas() {
    var dadosDivShellNew = this.state.dadosDivShellNew;
    var ufsnaototalizadas = '';
    for (var i = 0; i < dadosDivShellNew.length; i++) {
      if (dadosDivShellNew[i].secoesTotalizadas === '0') {
        ufsnaototalizadas =
          ufsnaototalizadas + dadosDivShellNew[i].uf.substring(0, 2) + ', ';
      }
    }
    return ufsnaototalizadas.substring(0, ufsnaototalizadas.length - 2);
  }
  renderUFsDivulgando() {
    var dadosDivShellNew = this.state.dadosDivShellNew;
    var ufsdivulgando = '';
    for (var i = 0; i < dadosDivShellNew.length; i++) {
      if (
        dadosDivShellNew[i].secoesTotalizadas !== '0' &&
        dadosDivShellNew[i].bloqueioDivulgacao === '-'
      ) {
        ufsdivulgando =
          ufsdivulgando + dadosDivShellNew[i].uf.substring(0, 2) + ', ';
      }
    }
    return ufsdivulgando.substring(0, ufsdivulgando.length - 2);
  }
  renderDivShell() {
    var rows = [];
    var dadosDivShellNew = this.state.dadosDivShellNew;
    var dadosDivShellOld = this.state.dadosDivShellOld;
    var classErroCand,
      classErroDiv,
      classErroJobs,
      classARC,
      classBrknJobs,
      classBloqueioDiv,
      classPendencias,
      classRejeicoes,
      classTotalizadas,
      dadosNew,
      dadosOld,
      cdabr;
    var getObjectByValue = function(array, key, value) {
      return array.filter(function(object) {
        return object[key] === value;
      });
    };
    for (var i = 0; i < abrangencias.length; i++) {
      if (abrangencias[i].id === 'BR') {
        cdabr = abrangencias[i].id;
      } else {
        cdabr = abrangencias[i].id + '2';
      }
      dadosNew = getObjectByValue(dadosDivShellNew, 'uf', cdabr);
      dadosOld = getObjectByValue(dadosDivShellOld, 'uf', cdabr);
      if (dadosNew.length === 0) {
        rows.push(
          <tr
            data-toggle="tooltip"
            data-placement="left"
            title={abrangencias[i].id}
            key={i}
          >
            <td className="p-0">
              <img
                height="16"
                className="border rounded"
                src={'img/' + abrangencias[i].id.toLowerCase() + '.png'}
                alt={abrangencias[i].id.toLowerCase()}
              />
            </td>
            <td className="p-0 text-danger" colSpan="17">
              <strong>Não há dados disponíveis!</strong>
            </td>
          </tr>
        );
      } else {
        if (dadosOld.length === 0) {
          dadosOld = dadosNew;
        }
        classARC = dadosNew[0].arc > '0' ? ' text-primary' : '';
        classErroCand = dadosNew[0].erroCand > '0' ? ' text-danger' : '';
        classErroDiv = dadosNew[0].erroDiv > '0' ? ' text-danger' : '';
        classErroJobs = dadosNew[0].erroJobs > '0' ? ' text-danger' : '';
        classBrknJobs = dadosNew[0].jobsQuebrados > '0' ? ' text-danger' : '';
        classBloqueioDiv =
          dadosNew[0].bloqueioDivulgacao !== '-' ? 'badge badge-danger' : '';
        classPendencias = dadosNew[0].pendencias > '0' ? ' text-danger' : '';
        classRejeicoes = dadosNew[0].rejeicoes > '0' ? ' text-danger' : '';
        classTotalizadas =
          dadosNew[0].secoesTotalizadas > '0' ? ' text-success' : '';
        rows.push(
          <tr
            data-toggle="tooltip"
            data-placement="left"
            title={abrangencias[i].id}
            key={i}
          >
            <td className="p-0">
              <img
                height="16"
                className="border rounded"
                src={'img/' + abrangencias[i].id.toLowerCase() + '.png'}
                alt={abrangencias[i].id.toLowerCase()}
              />
            </td>
            <td className="p-0 text-right colunasecao">
              {dadosNew[0].secoesNaoRecebidas !==
              dadosOld[0].secoesNaoRecebidas ? (
                <strong> {dadosNew[0].secoesNaoRecebidas} </strong>
              ) : (
                dadosOld[0].secoesNaoRecebidas
              )}
              &nbsp;
            </td>
            <td className="p-0 text-right colunasecao">
              {dadosNew[0].secoesNaoTotalizadas !==
              dadosOld[0].secoesNaoTotalizadas ? (
                <strong> {dadosNew[0].secoesNaoTotalizadas} </strong>
              ) : (
                dadosOld[0].secoesNaoTotalizadas
              )}
              &nbsp;
            </td>
            <td className={'p-0 text-right colunasecao' + classTotalizadas}>
              {dadosNew[0].secoesTotalizadas !==
              dadosOld[0].secoesTotalizadas ? (
                <strong> {dadosNew[0].secoesTotalizadas} </strong>
              ) : (
                dadosOld[0].secoesTotalizadas
              )}
              &nbsp;
            </td>
            <td className={'p-0 text-right colunasecao' + classPendencias}>
              {dadosNew[0].pendencias !== dadosOld[0].pendencias ? (
                <strong> {dadosNew[0].pendencias} </strong>
              ) : (
                dadosOld[0].pendencias
              )}
              &nbsp;
            </td>
            <td className={'p-0 text-right colunasecao' + classRejeicoes}>
              {dadosNew[0].rejeicoes !== dadosOld[0].rejeicoes ? (
                <strong> {dadosNew[0].rejeicoes} </strong>
              ) : (
                dadosOld[0].rejeicoes
              )}
              &nbsp;
            </td>
            <td className="p-0 colunadiv">
              <span className={classBloqueioDiv}>
                {dadosNew[0].bloqueioDivulgacao}
              </span>
            </td>
            <td className={'p-0 colunadiv' + classErroDiv}>
              {dadosNew[0].erroDiv !== dadosOld[0].erroDiv ? (
                <strong> {dadosNew[0].erroDiv} </strong>
              ) : (
                dadosOld[0].erroDiv
              )}
            </td>
            <td className="p-0 colunahora">
              {dadosNew[0].dataHoraTotalizacaoAgendada !==
              dadosOld[0].dataHoraTotalizacaoAgendada ? (
                <strong> {dadosNew[0].dataHoraTotalizacaoAgendada} </strong>
              ) : (
                dadosOld[0].dataHoraTotalizacaoAgendada
              )}
            </td>
            <td className="p-0 colunahora">
              {dadosNew[0].horarioLocal !== dadosOld[0].horarioLocal ? (
                <strong> {dadosNew[0].horarioLocal} </strong>
              ) : (
                dadosOld[0].horarioLocal
              )}
            </td>
            <td className="p-0 colunahora">
              {dadosNew[0].horarioUltimoBuRecebido !==
              dadosOld[0].horarioUltimoBuRecebido ? (
                <strong> {dadosNew[0].horarioUltimoBuRecebido} </strong>
              ) : (
                dadosOld[0].horarioUltimoBuRecebido
              )}
            </td>
            <td className="p-0 colunahora">
              {dadosNew[0].horarioUltimoBuTotalizado !==
              dadosOld[0].horarioUltimoBuTotalizado ? (
                <strong> {dadosNew[0].horarioUltimoBuTotalizado} </strong>
              ) : (
                dadosOld[0].horarioUltimoBuTotalizado
              )}
            </td>
            <td className="p-0 colunahora">
              {dadosNew[0].horarioPrimeiroBURecebido !==
              dadosOld[0].horarioPrimeiroBURecebido ? (
                <strong> {dadosNew[0].horarioPrimeiroBURecebido} </strong>
              ) : (
                dadosOld[0].horarioPrimeiroBURecebido
              )}
            </td>
            <td className={'p-0 colunacand' + classARC}>
              {dadosNew[0].arc !== dadosOld[0].arc ? (
                <strong> {dadosNew[0].arc} </strong>
              ) : (
                dadosOld[0].arc
              )}
            </td>
            <td className={'p-0 colunacand' + classErroCand}>
              {dadosNew[0].erroCand !== dadosOld[0].erroCand ? (
                <strong> {dadosNew[0].erroCand} </strong>
              ) : (
                dadosOld[0].erroCand
              )}
            </td>
            <td className="p-0  colunager">
              {dadosNew[0].andamentoTotalizacaoFinalMunicipal !==
              dadosOld[0].andamentoTotalizacaoFinalMunicipal ? (
                <strong>
                  {' '}
                  {dadosNew[0].andamentoTotalizacaoFinalMunicipal}{' '}
                </strong>
              ) : (
                dadosOld[0].andamentoTotalizacaoFinalMunicipal
              )}
            </td>
            <td className={'p-0 colunabrkn' + classErroJobs}>
              {dadosNew[0].erroJobs !== dadosOld[0].erroJobs ? (
                <strong> {dadosNew[0].erroJobs} </strong>
              ) : (
                dadosOld[0].erroJobs
              )}
            </td>
            <td className={'p-0 m-1 colunabrkn' + classBrknJobs}>
              {dadosNew[0].jobsQuebrados !== dadosOld[0].jobsQuebrados ? (
                <strong> {dadosNew[0].jobsQuebrados} </strong>
              ) : (
                dadosOld[0].jobsQuebrados
              )}
            </td>
          </tr>
        );
      }
    }
    return rows;
  }
  render() {
    const { isLoading } = this.state;
    if (isLoading) {
      return <p>Carregando ...</p>;
    }
    var ufsbloqueadas = this.renderUFsComBloqueioDivulgacao();
    var mostraUfsBloqueadas = ufsbloqueadas.length > 0 ? true : false;
    var ufsnaototalizadas = this.renderUFsNaoTotalizadas();
    var mostraUfsNaoTotalizadas = ufsnaototalizadas.length > 0 ? true : false;
    var ufsdivulgando = this.renderUFsDivulgando();
    var mostraUfsDivulgando = ufsdivulgando.length > 0 ? true : false;

    this.state.eleicoesDisponiveis.sort(this.GetSortOrderDesc('cd'));
    var showDivshellButton =
      this.state.dadosDivShellNew.length > 0 ? true : false;
    return (
      <div className="App">
        <div className="pos-f-t">
          <div className="collapse" id="navbarToggleExternalContent">
            <div className="bg-dark p-4">
              <h5 className="text-white">Configurações</h5>
              <form className="form-inline">
                <div
                  className="alert alert-success form-inline small center m-1"
                  role="alert"
                >
                  <label htmlFor="ambiente" className="small">
                    Url&nbsp;
                  </label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    placeholder="url de conexão"
                    value={this.state.url}
                    readOnly
                  />
                  &nbsp;&nbsp;
                  <label htmlFor="ambiente" className="small">
                    Ambiente&nbsp;
                  </label>
                  <select
                    className="custom-select custom-select-sm"
                    id="ambiente"
                    onChange={this.handleAmbienteChange}
                    value={this.state.ambiente}
                  >
                    <option value="homologacao">homologacao</option>
                    <option value="teste">teste</option>
                    <option value="simulado">simulado</option>
                    <option value="oficial">oficial</option>
                  </select>
                  &nbsp;&nbsp;
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id="showFlags"
                    checked={this.state.showFlags}
                    onChange={this.handleShowFlagsChange}
                  />
                  <label htmlFor="showFlags" className="small">
                    Mostrar bandeiras
                  </label>
                  &nbsp;&nbsp;&nbsp;
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id="mostrarFotos"
                    checked={this.state.mostrarFotos}
                    onChange={this.handleMostrarFotosChange}
                  />
                  <label htmlFor="mostrarFotos" className="small">
                    Mostrar fotos
                  </label>
                  &nbsp;&nbsp;&nbsp;
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id="eleicoesRecentes"
                    checked={this.state.mostrarEleicoesRecentes}
                    onChange={this.handleMostrarEleicoesRecentesChange}
                  />
                  <label htmlFor="eleicoesRecentes" className="small">
                    Apenas eleições recentes
                  </label>
                  &nbsp;&nbsp;&nbsp;
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id="chkValidacoes"
                    checked={this.state.chkValidacoes}
                    onChange={this.handleChkValidacoesChange}
                  />
                  <label htmlFor="chkValidacoes" className="small">
                    Validar arquivos
                  </label>
                  &nbsp;&nbsp;&nbsp;
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id="chkDivulgaShell"
                    checked={this.state.chkDivulgaShell}
                    onChange={this.handleChkDivulgaShellChange}
                  />
                  <label htmlFor="chkDivulgaShell" className="small">
                    Divulga Shell
                  </label>
                </div>
              </form>
            </div>
          </div>
          <nav className="navbar navbar-dark bg-dark">
            <a className="navbar-brand" href="#">
              <img
                src={logo}
                width="30"
                height="30"
                className="d-inline-block align-top"
                alt=""
              />
              DIV
            </a>
            <span className="float-right">
              {showDivshellButton && (
                <button
                  type="button"
                  className="btn btn-success"
                  data-toggle="modal"
                  data-target=".bd-erros-divulgacao-lg"
                  onClick={this.handleClickErrosDivulgacao}
                >
                  <img src="img/shell.svg" width="26" alt="Divulga Shell" />{' '}
                </button>
              )}{' '}
              {showDivshellButton && (
                <button
                  type="button"
                  className="btn btn-warning"
                  data-toggle="modal"
                  data-target=".bd-divulga-shell-lg"
                >
                  <img src="img/shell.svg" width="26" alt="Divulga Shell" />{' '}
                </button>
              )}{' '}
              <button
                className="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarToggleExternalContent"
                aria-controls="navbarToggleExternalContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon" />
              </button>
            </span>
          </nav>
        </div>
        <div
          className="modal fade bd-erros-divulgacao-lg p-2"
          tabIndex="-1"
          role="dialog"
          aria-labelledby="myLargeModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog modal-md p-0">
            <div className="modal-content p-1 border">
              <table className="table  table-striped table-hover fontsize11">
                <thead>
                  <tr>
                    <td colSpan="3">
                      <h6>Quantidade de erros da Divulgação</h6>
                    </td>
                  </tr>
                  <tr>
                    <td>host</td>
                    <td>últimos 10 minutos</td>
                    <td>últimos 20 minutos</td>
                  </tr>
                </thead>
                <tbody>{this.renderErrosDivulgacao()}</tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="container">
          <div className="form-group">
            <br />
            <form onSubmit={this.handleSubmit}>
              <div className="input-group">
                <select
                  data-toggle="tooltip"
                  data-placement="top"
                  title="Eleição"
                  id="comboEleicao"
                  onChange={this.handleEleicaoChange}
                  className="custom-select custom-select-sm"
                >
                  <option value="" key="">
                    Selecione a eleição
                  </option>
                  {this.renderComboEleicao()}
                </select>
                <div className="input-group-append">
                  <span
                    className="input-group"
                    id="inputGroupAppend2"
                    data-placement="top"
                    data-toggle="tooltip"
                    title="Abrangência"
                  >
                    <Abrangencia
                      abrangenciaSelecionada={this.state.abrangenciaSelecionada}
                      abrangenciasDisponiveis={
                        this.state.abrangenciasDisponiveis
                      }
                      onAbrangenciaChange={this.handleAbrangenciaChange}
                    />
                  </span>
                </div>
                <select
                  data-toggle="tooltip"
                  data-placement="top"
                  title="Município"
                  id="comboMunicipio"
                  onChange={this.handleMunicipioChange}
                  className="collapse custom-select custom-select-sm"
                  value={
                    this.state.municipioSelecionado !== undefined
                      ? this.state.municipioSelecionado.cd
                      : ''
                  }
                >
                  <option value="" key="">
                    Selecione o município
                  </option>
                  {this.renderComboMunicipio()}
                </select>
                <div className="input-group-append">
                  <button
                    className="btn btn-outline-secondary btn-sm"
                    type="button"
                    onClick={this.handleClick}
                  >
                    {' '}
                    {this.state.eleicoesCarregadas.length > 0
                      ? 'Atualizar'
                      : 'Consultar'}
                  </button>
                </div>
              </div>
            </form>
          </div>
          <nav>
            <div className="nav nav-tabs small" id="nav-tab" role="tablist">
              {this.renderTabCargo()}
              {this.state.arquivoDeIndice.length > 0 &&
                this.renderTabArquivoDeIndice()}
              {this.state.erroValidacaoJSON.length > 0 &&
                this.renderTabValidacaoJSON()}
              {this.state.erroValidacaoXML.length > 0 &&
                this.renderTabValidacaoXML()}
            </div>
          </nav>
          <div className="tab-content" id="nav-tabContent">
            {this.renderVotacao()}
            <div
              className="tab-pane fade p-2"
              id="nav-indice"
              key="nav-indice"
              role="tabpanel"
              aria-labelledby="nav-tab-indice"
            >
              {this.state.arquivoDeIndice.length > 0 && this.renderIndice()}
            </div>
            <div
              className="tab-pane fade p-2"
              id="nav-validacaojson"
              key="nav-validacaojson"
              role="tabpanel"
              aria-labelledby="nav-tab-validacaojson"
            >
              {this.state.erroValidacaoJSON.length > 0 &&
                this.renderLogValidacaoJSON()}
            </div>
            <div
              className="tab-pane fade p-2"
              id="nav-validacaoxml"
              key="nav-validacaoxml"
              role="tabpanel"
              aria-labelledby="nav-tab-validacaoxml"
            >
              {this.state.erroValidacaoXML.length > 0 &&
                this.renderLogValidacaoXML()}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
